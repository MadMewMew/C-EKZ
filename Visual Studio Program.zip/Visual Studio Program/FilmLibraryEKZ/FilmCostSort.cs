﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FilmLibraryEKZ
{
    public partial class FilmCostSort : Form
    {
        public FilmCostSort()
        {
            InitializeComponent();
        }

        private void FilmCostSort_Load(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Films ORDER BY Cost";

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Visual Studio Program\\FilmLibraryEKZ\\FilmLibraryDB.mdf\";Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable Table = new DataTable();
                adapter.Fill(Table);
                CostSortGrid.DataSource = Table;
            }
        }
        private void BackButton_Click(object sender, EventArgs e)
        {
            Main BackToMain = new Main();
            BackToMain.Show();
            this.Close();
        }
    }
}
