﻿namespace FilmLibraryEKZ
{
    partial class FilmsDate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.FilmsDateDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmsDateTranslation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmsDateGenre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmsDateCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmsDateCountry = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmsDateName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmsDateId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TableFilmsDate = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.TableFilmsDate)).BeginInit();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold);
            this.Title.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Title.Location = new System.Drawing.Point(12, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(164, 23);
            this.Title.TabIndex = 1;
            this.Title.Text = "ФИЛЬМОТЕКА";
            // 
            // FilmsDateDate
            // 
            this.FilmsDateDate.HeaderText = "Дата";
            this.FilmsDateDate.Name = "FilmsDateDate";
            // 
            // FilmsDateTranslation
            // 
            this.FilmsDateTranslation.HeaderText = "Переводов";
            this.FilmsDateTranslation.Name = "FilmsDateTranslation";
            // 
            // FilmsDateGenre
            // 
            this.FilmsDateGenre.HeaderText = "Жанр";
            this.FilmsDateGenre.Name = "FilmsDateGenre";
            // 
            // FilmsDateCost
            // 
            this.FilmsDateCost.HeaderText = "Бюджет";
            this.FilmsDateCost.Name = "FilmsDateCost";
            // 
            // FilmsDateCountry
            // 
            this.FilmsDateCountry.HeaderText = "Страна";
            this.FilmsDateCountry.Name = "FilmsDateCountry";
            // 
            // FilmsDateName
            // 
            this.FilmsDateName.HeaderText = "Название";
            this.FilmsDateName.Name = "FilmsDateName";
            // 
            // FilmsDateId
            // 
            this.FilmsDateId.HeaderText = "Id";
            this.FilmsDateId.Name = "FilmsDateId";
            // 
            // TableFilmsDate
            // 
            this.TableFilmsDate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TableFilmsDate.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FilmsDateId,
            this.FilmsDateName,
            this.FilmsDateCountry,
            this.FilmsDateCost,
            this.FilmsDateGenre,
            this.FilmsDateTranslation,
            this.FilmsDateDate});
            this.TableFilmsDate.Location = new System.Drawing.Point(12, 35);
            this.TableFilmsDate.Name = "TableFilmsDate";
            this.TableFilmsDate.Size = new System.Drawing.Size(760, 564);
            this.TableFilmsDate.TabIndex = 2;
            // 
            // FilmsDate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 611);
            this.Controls.Add(this.TableFilmsDate);
            this.Controls.Add(this.Title);
            this.MaximumSize = new System.Drawing.Size(800, 650);
            this.MinimumSize = new System.Drawing.Size(800, 650);
            this.Name = "FilmsDate";
            this.Text = "Фильмы по году выпуска";
            this.Load += new System.EventHandler(this.FilmsDate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TableFilmsDate)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmsDateDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmsDateTranslation;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmsDateGenre;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmsDateCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmsDateCountry;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmsDateName;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmsDateId;
        private System.Windows.Forms.DataGridView TableFilmsDate;
    }
}