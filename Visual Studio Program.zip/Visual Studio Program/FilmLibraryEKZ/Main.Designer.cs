﻿namespace FilmLibraryEKZ
{
    partial class Main
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.Title = new System.Windows.Forms.Label();
            this.FilmListBox = new System.Windows.Forms.ComboBox();
            this.RequestButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Title
            // 
            resources.ApplyResources(this.Title, "Title");
            this.Title.Name = "Title";
            // 
            // FilmListBox
            // 
            resources.ApplyResources(this.FilmListBox, "FilmListBox");
            this.FilmListBox.FormattingEnabled = true;
            this.FilmListBox.Items.AddRange(new object[] {
            resources.GetString("FilmListBox.Items"),
            resources.GetString("FilmListBox.Items1"),
            resources.GetString("FilmListBox.Items2"),
            resources.GetString("FilmListBox.Items3")});
            this.FilmListBox.Name = "FilmListBox";
            this.FilmListBox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // RequestButton
            // 
            resources.ApplyResources(this.RequestButton, "RequestButton");
            this.RequestButton.Name = "RequestButton";
            this.RequestButton.UseVisualStyleBackColor = true;
            this.RequestButton.Click += new System.EventHandler(this.RequestButton_Click);
            // 
            // ExitButton
            // 
            resources.ApplyResources(this.ExitButton, "ExitButton");
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Main
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.RequestButton);
            this.Controls.Add(this.FilmListBox);
            this.Controls.Add(this.Title);
            this.Name = "Main";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.ComboBox FilmListBox;
        private System.Windows.Forms.Button RequestButton;
        private System.Windows.Forms.Button ExitButton;
    }
}

