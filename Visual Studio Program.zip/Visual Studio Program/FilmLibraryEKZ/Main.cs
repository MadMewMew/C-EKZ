﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FilmLibraryEKZ
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (FilmListBox.SelectedIndex == 0)
            {
                FilmDateSort Form_Transition = new FilmDateSort();
                Form_Transition.Show();
                this.Hide();
            }
            if (FilmListBox.SelectedIndex == 1)
            {
                FilmAlphabetSort Form_Transition = new FilmAlphabetSort();
                Form_Transition.Show();
                this.Hide();
            }
            if(FilmListBox.SelectedIndex == 2)
            {
                FilmCostSort Form_Transition = new FilmCostSort();
                Form_Transition.Show();
                this.Hide();
            }
            if(FilmListBox.SelectedIndex == 3)
            {
                FilmCountrySort Form_Transition = new FilmCountrySort();
                Form_Transition.Show();
                this.Hide();
            }
        }
        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void RequestButton_Click(object sender, EventArgs e)
        {
            RequestForm Form_Transition = new RequestForm();
            Form_Transition.Show();
            this.Hide();
        }
    }
}