﻿namespace FilmLibraryEKZ
{
    partial class RequestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BackButton = new System.Windows.Forms.Button();
            this.Title = new System.Windows.Forms.Label();
            this.MostCostFilmButton = new System.Windows.Forms.Button();
            this.MostPopularFilmButton = new System.Windows.Forms.Button();
            this.OldestFilmButton = new System.Windows.Forms.Button();
            this.DataGridForRequests = new System.Windows.Forms.DataGridView();
            this.GenrelessCostLabel = new System.Windows.Forms.Label();
            this.GenrelessCostButton = new System.Windows.Forms.Button();
            this.GenrelessCost_GenreBox = new System.Windows.Forms.ComboBox();
            this.GenrelessCost_NameBox = new System.Windows.Forms.ComboBox();
            this.GenrelessCost_CountryMadeBox = new System.Windows.Forms.ComboBox();
            this.MaleActorsOrParisButton = new System.Windows.Forms.Button();
            this.CostLimitsButton = new System.Windows.Forms.Button();
            this.CostLimits_FirstLimit = new System.Windows.Forms.TextBox();
            this.CostLimits_SecondLimit = new System.Windows.Forms.TextBox();
            this.CostLimitsLabel = new System.Windows.Forms.Label();
            this.CostLimits_CountryBox = new System.Windows.Forms.ComboBox();
            this.CostLimits_DateBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.MaleActorsButton = new System.Windows.Forms.Button();
            this.BruceFilmsButton = new System.Windows.Forms.Button();
            this.ActorPresidentButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridForRequests)).BeginInit();
            this.SuspendLayout();
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(233, 9);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(75, 23);
            this.BackButton.TabIndex = 4;
            this.BackButton.Text = "НАЗАД";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold);
            this.Title.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Title.Location = new System.Drawing.Point(12, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(164, 23);
            this.Title.TabIndex = 3;
            this.Title.Text = "ФИЛЬМОТЕКА";
            // 
            // MostCostFilmButton
            // 
            this.MostCostFilmButton.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MostCostFilmButton.Location = new System.Drawing.Point(12, 214);
            this.MostCostFilmButton.Name = "MostCostFilmButton";
            this.MostCostFilmButton.Size = new System.Drawing.Size(295, 23);
            this.MostCostFilmButton.TabIndex = 12;
            this.MostCostFilmButton.Text = "Фильм с самым большим бюджетом";
            this.MostCostFilmButton.UseVisualStyleBackColor = true;
            this.MostCostFilmButton.Click += new System.EventHandler(this.MostCostFilmButton_Click);
            // 
            // MostPopularFilmButton
            // 
            this.MostPopularFilmButton.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MostPopularFilmButton.Location = new System.Drawing.Point(12, 243);
            this.MostPopularFilmButton.Name = "MostPopularFilmButton";
            this.MostPopularFilmButton.Size = new System.Drawing.Size(295, 23);
            this.MostPopularFilmButton.TabIndex = 13;
            this.MostPopularFilmButton.Text = "Самый популярный фильм";
            this.MostPopularFilmButton.UseVisualStyleBackColor = true;
            this.MostPopularFilmButton.Click += new System.EventHandler(this.MostPopularFilmButton_Click);
            // 
            // OldestFilmButton
            // 
            this.OldestFilmButton.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.OldestFilmButton.Location = new System.Drawing.Point(12, 272);
            this.OldestFilmButton.Name = "OldestFilmButton";
            this.OldestFilmButton.Size = new System.Drawing.Size(295, 23);
            this.OldestFilmButton.TabIndex = 14;
            this.OldestFilmButton.Text = "Самый старый фильм";
            this.OldestFilmButton.UseVisualStyleBackColor = true;
            this.OldestFilmButton.Click += new System.EventHandler(this.OldestFilmButton_Click);
            // 
            // DataGridForRequests
            // 
            this.DataGridForRequests.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridForRequests.Location = new System.Drawing.Point(12, 35);
            this.DataGridForRequests.Name = "DataGridForRequests";
            this.DataGridForRequests.Size = new System.Drawing.Size(760, 173);
            this.DataGridForRequests.TabIndex = 15;
            // 
            // GenrelessCostLabel
            // 
            this.GenrelessCostLabel.AutoSize = true;
            this.GenrelessCostLabel.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GenrelessCostLabel.Location = new System.Drawing.Point(339, 210);
            this.GenrelessCostLabel.Name = "GenrelessCostLabel";
            this.GenrelessCostLabel.Size = new System.Drawing.Size(403, 32);
            this.GenrelessCostLabel.TabIndex = 18;
            this.GenrelessCostLabel.Text = "Для заданного жанра определить фильмы, чья стоимость\r\n меньше, чем заданный фильм" +
    " из заданной страны";
            // 
            // GenrelessCostButton
            // 
            this.GenrelessCostButton.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.GenrelessCostButton.Location = new System.Drawing.Point(614, 259);
            this.GenrelessCostButton.Name = "GenrelessCostButton";
            this.GenrelessCostButton.Size = new System.Drawing.Size(146, 23);
            this.GenrelessCostButton.TabIndex = 19;
            this.GenrelessCostButton.Text = "Определить";
            this.GenrelessCostButton.UseVisualStyleBackColor = true;
            this.GenrelessCostButton.Click += new System.EventHandler(this.GenrelessCostButton_Click);
            // 
            // GenrelessCost_GenreBox
            // 
            this.GenrelessCost_GenreBox.FormattingEnabled = true;
            this.GenrelessCost_GenreBox.Location = new System.Drawing.Point(313, 274);
            this.GenrelessCost_GenreBox.Name = "GenrelessCost_GenreBox";
            this.GenrelessCost_GenreBox.Size = new System.Drawing.Size(144, 21);
            this.GenrelessCost_GenreBox.TabIndex = 20;
            // 
            // GenrelessCost_NameBox
            // 
            this.GenrelessCost_NameBox.FormattingEnabled = true;
            this.GenrelessCost_NameBox.Location = new System.Drawing.Point(313, 245);
            this.GenrelessCost_NameBox.Name = "GenrelessCost_NameBox";
            this.GenrelessCost_NameBox.Size = new System.Drawing.Size(295, 21);
            this.GenrelessCost_NameBox.TabIndex = 21;
            // 
            // GenrelessCost_CountryMadeBox
            // 
            this.GenrelessCost_CountryMadeBox.FormattingEnabled = true;
            this.GenrelessCost_CountryMadeBox.Location = new System.Drawing.Point(462, 274);
            this.GenrelessCost_CountryMadeBox.Name = "GenrelessCost_CountryMadeBox";
            this.GenrelessCost_CountryMadeBox.Size = new System.Drawing.Size(146, 21);
            this.GenrelessCost_CountryMadeBox.TabIndex = 22;
            // 
            // MaleActorsOrParisButton
            // 
            this.MaleActorsOrParisButton.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.MaleActorsOrParisButton.Location = new System.Drawing.Point(12, 301);
            this.MaleActorsOrParisButton.Name = "MaleActorsOrParisButton";
            this.MaleActorsOrParisButton.Size = new System.Drawing.Size(295, 23);
            this.MaleActorsOrParisButton.TabIndex = 23;
            this.MaleActorsOrParisButton.Text = "Актёры мужчины или в Париже";
            this.MaleActorsOrParisButton.UseVisualStyleBackColor = true;
            this.MaleActorsOrParisButton.Click += new System.EventHandler(this.MaleActorsOrParisButton_Click);
            // 
            // CostLimitsButton
            // 
            this.CostLimitsButton.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.CostLimitsButton.Location = new System.Drawing.Point(614, 387);
            this.CostLimitsButton.Name = "CostLimitsButton";
            this.CostLimitsButton.Size = new System.Drawing.Size(146, 23);
            this.CostLimitsButton.TabIndex = 24;
            this.CostLimitsButton.Text = "Определить";
            this.CostLimitsButton.UseVisualStyleBackColor = true;
            this.CostLimitsButton.Click += new System.EventHandler(this.CostLimitsButton_Click);
            // 
            // CostLimits_FirstLimit
            // 
            this.CostLimits_FirstLimit.Location = new System.Drawing.Point(313, 377);
            this.CostLimits_FirstLimit.Name = "CostLimits_FirstLimit";
            this.CostLimits_FirstLimit.Size = new System.Drawing.Size(144, 20);
            this.CostLimits_FirstLimit.TabIndex = 25;
            // 
            // CostLimits_SecondLimit
            // 
            this.CostLimits_SecondLimit.Location = new System.Drawing.Point(462, 377);
            this.CostLimits_SecondLimit.Name = "CostLimits_SecondLimit";
            this.CostLimits_SecondLimit.Size = new System.Drawing.Size(146, 20);
            this.CostLimits_SecondLimit.TabIndex = 26;
            // 
            // CostLimitsLabel
            // 
            this.CostLimitsLabel.AutoSize = true;
            this.CostLimitsLabel.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CostLimitsLabel.Location = new System.Drawing.Point(340, 315);
            this.CostLimitsLabel.Name = "CostLimitsLabel";
            this.CostLimitsLabel.Size = new System.Drawing.Size(371, 32);
            this.CostLimitsLabel.TabIndex = 28;
            this.CostLimitsLabel.Text = "Найти фильмы со стоимостью в заданных рамках по \r\nзаданнаму году выпуска и заданн" +
    "ой стране\r\n";
            // 
            // CostLimits_CountryBox
            // 
            this.CostLimits_CountryBox.FormattingEnabled = true;
            this.CostLimits_CountryBox.Location = new System.Drawing.Point(462, 403);
            this.CostLimits_CountryBox.Name = "CostLimits_CountryBox";
            this.CostLimits_CountryBox.Size = new System.Drawing.Size(146, 21);
            this.CostLimits_CountryBox.TabIndex = 30;
            // 
            // CostLimits_DateBox
            // 
            this.CostLimits_DateBox.FormattingEnabled = true;
            this.CostLimits_DateBox.Location = new System.Drawing.Point(313, 403);
            this.CostLimits_DateBox.Name = "CostLimits_DateBox";
            this.CostLimits_DateBox.Size = new System.Drawing.Size(144, 21);
            this.CostLimits_DateBox.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.label1.Location = new System.Drawing.Point(340, 358);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 16);
            this.label1.TabIndex = 31;
            this.label1.Text = "Первая рамка";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.label2.Location = new System.Drawing.Point(485, 358);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 16);
            this.label2.TabIndex = 32;
            this.label2.Text = "Вторая рамка";
            // 
            // MaleActorsButton
            // 
            this.MaleActorsButton.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.MaleActorsButton.Location = new System.Drawing.Point(12, 330);
            this.MaleActorsButton.Name = "MaleActorsButton";
            this.MaleActorsButton.Size = new System.Drawing.Size(295, 23);
            this.MaleActorsButton.TabIndex = 33;
            this.MaleActorsButton.Text = "Актёры мужчины в фильме Терминатор";
            this.MaleActorsButton.UseVisualStyleBackColor = true;
            this.MaleActorsButton.Click += new System.EventHandler(this.MaleActorsButton_Click);
            // 
            // BruceFilmsButton
            // 
            this.BruceFilmsButton.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.BruceFilmsButton.Location = new System.Drawing.Point(12, 359);
            this.BruceFilmsButton.Name = "BruceFilmsButton";
            this.BruceFilmsButton.Size = new System.Drawing.Size(295, 23);
            this.BruceFilmsButton.TabIndex = 34;
            this.BruceFilmsButton.Text = "Фильмы в которых играл Брюс Уиллис";
            this.BruceFilmsButton.UseVisualStyleBackColor = true;
            this.BruceFilmsButton.Click += new System.EventHandler(this.BruceFilmsButton_Click);
            // 
            // ActorPresidentButton
            // 
            this.ActorPresidentButton.Font = new System.Drawing.Font("Verdana", 9.75F);
            this.ActorPresidentButton.Location = new System.Drawing.Point(12, 388);
            this.ActorPresidentButton.Name = "ActorPresidentButton";
            this.ActorPresidentButton.Size = new System.Drawing.Size(295, 23);
            this.ActorPresidentButton.TabIndex = 35;
            this.ActorPresidentButton.Text = "Актёры, также президенты киностудий";
            this.ActorPresidentButton.UseVisualStyleBackColor = true;
            this.ActorPresidentButton.Click += new System.EventHandler(this.ActorPresidentButton_Click);
            // 
            // RequestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 611);
            this.Controls.Add(this.ActorPresidentButton);
            this.Controls.Add(this.BruceFilmsButton);
            this.Controls.Add(this.MaleActorsButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CostLimits_CountryBox);
            this.Controls.Add(this.CostLimits_DateBox);
            this.Controls.Add(this.CostLimitsLabel);
            this.Controls.Add(this.CostLimits_SecondLimit);
            this.Controls.Add(this.CostLimits_FirstLimit);
            this.Controls.Add(this.CostLimitsButton);
            this.Controls.Add(this.MaleActorsOrParisButton);
            this.Controls.Add(this.GenrelessCost_CountryMadeBox);
            this.Controls.Add(this.GenrelessCost_NameBox);
            this.Controls.Add(this.GenrelessCost_GenreBox);
            this.Controls.Add(this.GenrelessCostButton);
            this.Controls.Add(this.GenrelessCostLabel);
            this.Controls.Add(this.DataGridForRequests);
            this.Controls.Add(this.OldestFilmButton);
            this.Controls.Add(this.MostPopularFilmButton);
            this.Controls.Add(this.MostCostFilmButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.Title);
            this.MaximumSize = new System.Drawing.Size(800, 650);
            this.MinimumSize = new System.Drawing.Size(800, 650);
            this.Name = "RequestForm";
            this.Text = "Форма с запросами";
            this.Load += new System.EventHandler(this.RequestForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridForRequests)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Button MostCostFilmButton;
        private System.Windows.Forms.Button MostPopularFilmButton;
        private System.Windows.Forms.Button OldestFilmButton;
        private System.Windows.Forms.DataGridView DataGridForRequests;
        private System.Windows.Forms.Label GenrelessCostLabel;
        private System.Windows.Forms.Button GenrelessCostButton;
        private System.Windows.Forms.ComboBox GenrelessCost_GenreBox;
        private System.Windows.Forms.ComboBox GenrelessCost_NameBox;
        private System.Windows.Forms.ComboBox GenrelessCost_CountryMadeBox;
        private System.Windows.Forms.Button MaleActorsOrParisButton;
        private System.Windows.Forms.Button CostLimitsButton;
        private System.Windows.Forms.TextBox CostLimits_FirstLimit;
        private System.Windows.Forms.TextBox CostLimits_SecondLimit;
        private System.Windows.Forms.Label CostLimitsLabel;
        private System.Windows.Forms.ComboBox CostLimits_CountryBox;
        private System.Windows.Forms.ComboBox CostLimits_DateBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button MaleActorsButton;
        private System.Windows.Forms.Button BruceFilmsButton;
        private System.Windows.Forms.Button ActorPresidentButton;
    }
}