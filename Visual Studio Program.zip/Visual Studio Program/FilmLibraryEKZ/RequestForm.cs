﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FilmLibraryEKZ
{
    public partial class RequestForm : Form
    {
        public RequestForm()
        {
            InitializeComponent();
        }

        private void RequestForm_Load(object sender, EventArgs e)
        {
            string query = "SELECT DISTINCT Genre From Films";
            
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Visual Studio Program\\FilmLibraryEKZ\\FilmLibraryDB.mdf\";Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable Table = new DataTable();
                adapter.Fill(Table);
                GenrelessCost_GenreBox.DataSource = Table;
                GenrelessCost_GenreBox.DisplayMember = "Genre";
            }

            query = "SELECT DISTINCT Name From Films";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable Table = new DataTable();
                adapter.Fill(Table);
                GenrelessCost_NameBox.DataSource = Table;
                GenrelessCost_NameBox.DisplayMember = "Name";
            }

            query = "SELECT DISTINCT CountryMade From Films";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable Table = new DataTable();
                adapter.Fill(Table);
                GenrelessCost_CountryMadeBox.DataSource = Table;
                GenrelessCost_CountryMadeBox.DisplayMember = "CountryMade";
                CostLimits_CountryBox.DataSource = Table;
                CostLimits_CountryBox.DisplayMember = "CountryMade";
            }

            query = "SELECT Date FROM Films";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable Table = new DataTable();
                adapter.Fill(Table);
                CostLimits_DateBox.DataSource = Table;
                CostLimits_DateBox.DisplayMember = "Date";
            }
        }
        private void BackButton_Click(object sender, EventArgs e)
        {
            Main BackToMain = new Main();
            BackToMain.Show();
            this.Close();
        }

        private void MostCostFilmButton_Click(object sender, EventArgs e)
        {
            string query = "SELECT Name , Cost FROM Films WHERE Cost = (SELECT MAX(Cost) FROM Films)";

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Visual Studio Program\\FilmLibraryEKZ\\FilmLibraryDB.mdf\";Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable Table = new DataTable();
                adapter.Fill(Table);
                DataGridForRequests.DataSource = Table;
            }
        }

        private void MostPopularFilmButton_Click(object sender, EventArgs e)
        {
            string query = "SELECT Films.Name FROM Films INNER JOIN Films_Countries_Link " +
                           "INNER JOIN Countries ON Countries.Id = Films_Countries_Link.Id_Country " +
                           "ON Films.Id = Films_Countries_Link.Id_Film WHERE Countries.RentalCount = " +
                           "(SELECT MAX(Countries.RentalCount) FROM Countries)";

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Visual Studio Program\\FilmLibraryEKZ\\FilmLibraryDB.mdf\";Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable Table = new DataTable();
                adapter.Fill(Table);
                DataGridForRequests.DataSource = Table;
            }
        }

        private void OldestFilmButton_Click(object sender, EventArgs e)
        {
            string query = "SELECT Name , Date FROM Films WHERE Date = (SELECT MIN(Date) From Films)";

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Visual Studio Program\\FilmLibraryEKZ\\FilmLibraryDB.mdf\";Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable Table = new DataTable();
                adapter.Fill(Table);
                DataGridForRequests.DataSource = Table;
            }
        }
        private void GenrelessCostButton_Click(object sender, EventArgs e)
        {
            string query = @"SELECT Name, Cost FROM Films WHERE Genre = @Genre AND Cost < 
                            (SELECT Cost FROM Films WHERE Name = @Name AND CountryMade = @CountryMade)";

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Visual Studio Program\\FilmLibraryEKZ\\FilmLibraryDB.mdf\";Integrated Security=True";

            string SelectedGenre = GenrelessCost_GenreBox.GetItemText(GenrelessCost_GenreBox.SelectedItem);
            string SelectedName = GenrelessCost_NameBox.GetItemText(GenrelessCost_NameBox.SelectedItem);
            string SelectedCountryMade = GenrelessCost_CountryMadeBox.GetItemText(GenrelessCost_CountryMadeBox.SelectedItem);
            try
            {

            }
            catch 
            {

            }
            try
            {

            }
            catch
            {

            }
            try
            {

            }
            catch
            {

            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Genre", SelectedGenre);
                    command.Parameters.AddWithValue("@Name", SelectedName);
                    command.Parameters.AddWithValue("@CountryMade", SelectedCountryMade);
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    DataGridForRequests.DataSource = dataTable;
                }
            }
        }

        private void MaleActorsOrParisButton_Click(object sender, EventArgs e)
        {
            string query = @"SELECT Name , Country , Gender FROM Actors WHERE Country = @Country OR Gender = @Gender";

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Visual Studio Program\\FilmLibraryEKZ\\FilmLibraryDB.mdf\";Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Country", "Париж");
                    command.Parameters.AddWithValue("@Gender", "М");
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    DataGridForRequests.DataSource = dataTable;
                }
            }
        }

        private void CostLimitsButton_Click(object sender, EventArgs e)
        {
            string query = @"SELECT Films.Name FROM Films INNER JOIN Films_Countries_Link INNER JOIN Countries 
                             ON Countries.Id = Films_Countries_Link.Id_Country ON Films.Id = Films_Countries_Link.Id_Film 
                             WHERE Films.Cost BETWEEN @FirstLimit AND @SecondLimit AND Countries.Name = @CountryName
                             AND Films.Date = @FilmDate";

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Visual Studio Program\\FilmLibraryEKZ\\FilmLibraryDB.mdf\";Integrated Security=True";
            int SelectedFirstLimit = 0;
            int SelectedSecondLimit = 0;
            string SelectedCountryName = "";
            string SelectedFilmDateString = "";
            DateTime SelectedFilmDate = DateTime.Now;
            try
            {
                SelectedFirstLimit = Convert.ToInt32(CostLimits_FirstLimit.Text);
            }
            catch
            {
                MessageBox.Show("Ошибка ввода в первой рамке.");
            }
            try
            {
                SelectedSecondLimit = Convert.ToInt32(CostLimits_SecondLimit.Text);
            }
            catch
            {
                MessageBox.Show("Ошибка ввода во второй рамке.");
            }
            try
            {
                SelectedCountryName = CostLimits_CountryBox.GetItemText(CostLimits_CountryBox.SelectedItem);
            }
            catch
            {
                MessageBox.Show("Ошибка ввода в строке страны.");
            }
            try
            {
                SelectedFilmDate = DateTime.Parse(SelectedFilmDateString);
            }
            catch
            {
                MessageBox.Show("Ошибка ввода в строке даты.");
            }
            int tmp = 0;
            if (SelectedFirstLimit > SelectedSecondLimit)
            {
                SelectedSecondLimit = tmp;
                SelectedSecondLimit = SelectedFirstLimit;
                SelectedFirstLimit = tmp;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@FirstLimit", SelectedFirstLimit);
                    command.Parameters.AddWithValue("@SecondLimit", SelectedSecondLimit);
                    command.Parameters.AddWithValue("@CountryName", SelectedCountryName);
                    command.Parameters.AddWithValue("@FilmDate", SelectedFilmDate);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    DataGridForRequests.DataSource = dataTable;
                }
            }
        }

        private void MaleActorsButton_Click(object sender, EventArgs e)
        {
            string query = @"SELECT Actors.Name , Actors.Gender FROM Films INNER JOIN Films_Actors_Link INNER JOIN Actors
                             ON Actors.Id = Films_Actors_Link.Id_Actor ON Films.Id = Films_Actors_Link.Id_Film 
                             WHERE Films.Name = @FilmName AND Actors.Gender = @ActorGender";

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Visual Studio Program\\FilmLibraryEKZ\\FilmLibraryDB.mdf\";Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@FilmName", "Терминатор");
                    command.Parameters.AddWithValue("@ActorGender", "М");
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    DataGridForRequests.DataSource = dataTable;
                }
            }
        }

        private void BruceFilmsButton_Click(object sender, EventArgs e)
        {
            string query = @"SELECT Films.Name FROM Actors INNER JOIN Films_Actors_Link INNER JOIN Films 
                             ON Actors.Id = Films_Actors_Link.Id_Actor ON Films.Id = Films_Actors_Link.Id_Film
                             WHERE Actors.Name = @ActorName";

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Visual Studio Program\\FilmLibraryEKZ\\FilmLibraryDB.mdf\";Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ActorName", "Брюс Уиллис");
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    DataGridForRequests.DataSource = dataTable;
                }
            }
        }

        private void ActorPresidentButton_Click(object sender, EventArgs e)
        {
            string query = @"SELECT DISTINCT Studios.President , Studios.Studio , Actors.AdditionalProfession FROM Actors , Studios
                             WHERE Actors.AdditionalProfession = @ActorAddProf";

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\Visual Studio Program\\FilmLibraryEKZ\\FilmLibraryDB.mdf\";Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ActorAddProf", "Президент киностудии");
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    DataGridForRequests.DataSource = dataTable;
                }
            }
            
        }
    }
}